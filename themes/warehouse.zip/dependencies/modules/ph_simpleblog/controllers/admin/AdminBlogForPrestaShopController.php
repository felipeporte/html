<?php

class AdminBlogForPrestaShopController extends ModuleAdminController
{
}
