<?php
/**
 * Blog for PrestaShop module by Krystian Podemski from PrestaHome.
 *
 * @author    Krystian Podemski <krystian@prestahome.com>
 * @copyright Copyright (c) 2008-2020 Krystian Podemski - www.PrestaHome.com / www.Podemski.info
 * @license   You only can use module, nothing more!
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_7_6($module)
{
    $module->hasFieldInDatabaseIfNotCreateOne('simpleblog_author', 'link_rewrite', 'VARCHAR(128) AFTER `www`');

    return true;
}
