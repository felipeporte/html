# PrestaShop Warehouse Theme

The Warehouse Theme is based on Prestashop 1.7 Classic theme.
